MIKME COINS Telegram Mini App — starter prototype

WHAT THIS IS
- A mobile-first visual prototype inspired by the mining dashboard reference.
- Includes a working demo tap button, local demo balance and energy counter.
- Loads Telegram's Web App SDK and displays the Telegram user's first name when opened inside Telegram.

IMPORTANT
- This is a FRONT-END PROTOTYPE only.
- The balance is stored locally in the browser and is not secure or shared across devices.
- No real cryptocurrency is created, mined, or transferred.
- Do not enable withdrawals until a secure backend, database, anti-cheat checks, and a real token/payment design have been implemented.
- Never put your Telegram bot token in index.html or any browser-side code.

HOW TO PREVIEW
1. Upload index.html to a static hosting service that gives you an HTTPS URL.
2. Open that URL in a browser to preview.
3. Once hosted, configure the Mini App URL in BotFather.
4. A production build still needs a backend to verify Telegram initData and save balances/referrals securely.

NEXT DEVELOPMENT TASKS
- Add server-side Telegram initData verification.
- Add database-backed balances and mining cooldown/energy rules.
- Add referral tracking and admin controls.
- Add wallet/withdrawal only after deciding whether MKC is just points or a real on-chain token.
